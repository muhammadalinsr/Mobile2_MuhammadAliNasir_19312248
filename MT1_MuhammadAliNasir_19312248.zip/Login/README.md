# SIMPLE LOGIN UI - JETPACK COMPOSE
## A Simple Android Login UI Application using Jetpack Compose

## LIBRARIES

### Compose Navigation Library - [Jetpack Compose Navigation](https://developer.android.com/jetpack/compose/navigation)

## SCREENSHOTS
![Login Page](screenshots/login.jpg)    ![Register Page](screenshots/register.jpg)

